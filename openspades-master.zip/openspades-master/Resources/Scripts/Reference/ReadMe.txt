
About Reference Directory
=========================

This directory contains a prototype declaration for public APIs which can be
used by game scripts. You can refer to the source codes in this directory for 
the definition of the provided APIs.

This directory is just for reference; do not include any scripts in this 
directory. They aren't meant to be compiled.
