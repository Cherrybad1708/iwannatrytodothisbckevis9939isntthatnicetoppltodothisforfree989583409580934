#pragma once

#include <string>

class VersionInfo {
public:
    static std::string GetVersionInfo();
};
